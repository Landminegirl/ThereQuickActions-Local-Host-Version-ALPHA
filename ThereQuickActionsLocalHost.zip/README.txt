ThereQuickActions LocalHost
===========================

SETUP OPTIONS
-------------

RECOMMENDED - OPEN INSIDE THERE
1. In the There game chat box type /local or /web.
2. Open CLICK TO LAUNCH.html in Windows.
3. Click Copy Local File Address.
4. Paste the address into the There browser Address bar.
5. Press Enter.

NORMAL BROWSER
Click Open ThereQuickActions File, or double-click
Open_ThereQuickActions.html.

LOCAL THERE PAGE
Open http://127.0.0.1:9999/ in your normal browser.

LAUNCHER BOOKMARK
Open CLICK TO LAUNCH.html and drag ThereQuickActions Launcher to
your bookmarks bar.

IN-GAME SETUP
-------------
1. In the There game chat box type /local or /web to open the There Browser Tab.
2. Open CLICK TO LAUNCH.html in Windows.
3. Click Copy Local File Address.
4. Paste the copied address into the Address bar in the There browser.
5. Press Enter.

ThereQuickActions will open inside the game browser.

OPTIONAL
--------
Click Open ThereQuickActions File to open the tool inside your normal browser.

SETUP OPTIONS
-------------
System Cockpit page:
1. Start There and enable System Cockpit.
2. Open http://127.0.0.1:9999/
3. Use the ThereQuickActions bookmark from the bookmarks bar.

Local file:
1. Start There and enable System Cockpit.
2. Double-click Open_ThereQuickActions.html.

Open CLICK TO LAUNCH.html for buttons and setup instructions.

QUICK START
-----------
1. Start There and enable System Cockpit.
2. Double-click Open_ThereQuickActions.html.

BOOKMARK SETUP
--------------
1. Open CLICK TO LAUNCH.html.
2. Keep the extracted folder somewhere you will not move it.
3. Drag ThereQuickActions Launcher to the bookmarks bar.
4. Click the bookmark to open the local interface.

AUTO DANCE
----------
Auto Dance contains three collapsible sections:

- Follow Another Avatar's Moves
- Saved Auto Dances
- Dance Builder

Use the > or v button in the top-left of a section to hide or show it.

Saved Auto Dances controls are at the top:

- Start
- Stop
- Loop On/Off
- Play Once
- Save Changes

The Dance Builder stays in the Auto Dance page.

Category tabs are generated from every command list available in the current
configuration, including custom command buttons when present.

Delay buttons appear directly under the category tabs.

Dance Steps can be selected, moved up or down, deleted, or cleared.

F-KEYS
------
Assign F1 through F12 or Shift+F1 through Shift+F10 to saved dances.

- Press an assigned key to start looping its dance.
- Press the same key again to stop it.
- Press a different assigned key to immediately switch dances.

F-keys work while the ThereQuickActions page is focused.

SCRIPT SENDING
--------------
Only one ScriptHook request is used per command.
A newline is appended so addChatText submits the command.


AUTO SAVE
---------
Dance changes save automatically when you:

- add a builder action
- add a delay
- move, delete, or clear steps
- edit the raw dance script
- rename a dance
- assign or remove an F-key

Save Changes remains available as a manual confirmation button.


ACTIVE DANCE DISPLAY
--------------------
When an assigned F-key starts a dance:

- Auto Dance opens automatically.
- The matching saved dance becomes selected and highlighted.
- The list displays "Playing" beside the active dance.
- The combined Start/Stop button changes to Stop.

Pressing the same F-key again stops the dance and changes the button back to
Start. Starting a different dance immediately switches playback.

SETTINGS
--------
The opacity control has been removed. The interface always uses full opacity.


CUSTOM BUTTONS AND TABS
-----------------------
Open the Custom tab to:

- create, edit, or delete custom buttons
- place a custom button in any built-in or user-created tab
- create new tabs
- delete tabs you created

Built-in tabs cannot be deleted. Deleting a user-created tab moves its custom
buttons back to the Custom tab.

TAB VISIBILITY
--------------
Open Settings to turn each action tab on or off individually. Settings always
remains visible. Diagnostics can also be shown or hidden.


TAB ORDER
---------
Open Settings and use the Up and Down buttons beside any action tab.

- Built-in tabs can be reordered.
- User-created tabs can be reordered.
- Hidden tabs keep their selected position.
- Settings remains fixed at the bottom so tabs can always be restored.


ADMIN TABS
----------
Admin Tabs are disabled by default.

Open Settings and enable "Enable admin tabs". A divider appears beneath
Settings and Diagnostics. These live service tabs appear below it:

AutoPilot
Causality
ClientLoginGui
DataDrivenSprintf
environment
fids
GuiService
ihost
inventoryManager
loginMan
LogManagementService
material
mgmt
oidpropBrowser
oidpropDbRemote
ovpClient
PerfKnobManager
ScriptHook
strings
SysMesgMessage
uudobman
VersionedXmlSvc

Each tab embeds the real local service page from http://127.0.0.1:9999/.
Submitting controls on editable service pages affects the running There client.
